#!/bin/sh

# ===================================================================
# GANYMED STARTUP SCRIPT
#
# Copyright (C) 2005-2006 by ETH Zurich and Christian Plattner
# plattner@inf.ethz.ch
#
# Used to install the Ganymed adapter software and start the adapter
# on a cluster node. To ease development and deployment, this script
# will install (overwrite) the software each time it is called.
#
# The script assumes that all needed files are in the same directory
# as itself (you can start it from anywhere, it will find its own
# location in the filesystem).
# ===================================================================

# ===================================================================
#
# Installation Layout:
#
# $TOPDIR/ganymed : This script will install the software there
# $TOPDIR/cluster : Here we expect the PostgreSQL installations
#
# For each cluster (the PostgreSQL notation for a DBMS installation,
# refers to "database cluster", e.g., a set of catalogs - we simply
# call it an "instance"), there is the "wal" and the "pgdata"
# subdirectory.
# The "wal" directory will automatically be created by the adapter
# when it finds a cluster (i.e., the pgdata directory).
# The PostgreSQL configuration in the pgdata diectory will be
# replaced by a Ganymed generated configuration (e.g., the database
# will be directed to only listen on localhost port 500X etc.)
#
# To initially create a DBMS (cluster in PostgreSQL notation) managed
# by Ganymed, do the following:
#
# initdb -D $TOPDIR/cluster/mycluster/pgdata
# initdb -D $TOPDIR/cluster/anothercluster/pgdata
# initdb -D $TOPDIR/cluster/test1/pgdata
# ...etc.etc.
#
# ... then restart the adapter by calling this script.
#
# ===================================================================

# ===================================================================
# CHANGE SETTINGS _HERE_ IF NEEDED
# ===================================================================

TOPDIR=/local/$USER

ADAPTER_PORT=5432
POSTGRESQL_INTERNAL_BASE_PORT=5000
MASTER_USER=$USER
MASTER_PASSWORD=bigsecret

# Java and PostgreSQL Settings

# JAVA_HOME=
# PGLOC=

# All adapter log4j output is sent to $TOPDIR/ganymed/$HOSTNAME.log

LOGLEVEL=info

# Enter below the hostname of the management console
# which will receive all Log4J messages.

LOG4JHOST=ikdesk2.inf.ethz.ch
LOG4JPORT=3333

# ===================================================================
# DON'T CHANGE ANYTHING BELOW HERE
# ===================================================================

STATISTICS=yes
XACT_REROUTE_LIMIT=10
JARS=pc.jar:log4j-1.2.13.jar:postgresql-8.1-405.jdbc3.jar

# ===================================================================
# GATHER DATA ABOUT CURRENT ENVIRONMENT
# ===================================================================

thismachine=`hostname -s`

# ===================================================================
# WHERE AM I?
# ===================================================================

MYSCRIPT="$0"

while [ -h "$MYSCRIPT" ]
do
	ls=`ls -ld "$MYSCRIPT"`
	link=`expr "$ls" : '.*-> \(.*\)$'`
	if expr "$link" : '/.*' > /dev/null
	then
		MYSCRIPT="$link"
	else
		MYSCRIPT=`dirname "$MYSCRIPT"`"/$link"
	fi
done

ganymedfiles=`dirname "$MYSCRIPT"`
ganymedfiles=`cd "$ganymedfiles" && pwd`

# ===================================================================
# TOPDIR SETTING
# ===================================================================

if [[ "Z$TOPDIR" == "Z" ]]
then
	echo "Please set the TOPDIR variable."
	exit 2
fi

if [ ! -e $TOPDIR ]
then
	echo "Creating TOPDIR ($TOPDIR)..."
	mkdir -p $TOPDIR
fi

if [ ! -d $TOPDIR ]
then
	echo "Please set the TOPDIR variable so that it points to a directory."
	exit 2
fi

# ===================================================================
# DEFAULT VALUES FOR IKS CLUSTERS AT ETH ZURICH
# ===================================================================

if [[ "Z$JAVA_HOME" == "Z" ]]
then
  archname=`uname -m`
  # Are we on one of the AMD64 machines (i.e., IKR cluster) ???
  if test $archname = "x86_64"
  then
    #JAVA_HOME=/pub/A1000/java/Blackdown-1.4.2-AMD64
    JAVA_HOME=/pub/A1000/java/jdk1.5.0-amd64
  else
    #JAVA_HOME=/pub/A1000/java/Blackdown-1.4.2
    JAVA_HOME=/pub/A1000/java/jdk1.5.0
  fi
  if [ ! -d $JAVA_HOME ]
  then
    JAVA_HOME=
  fi
fi

if [[ "Z$PGLOC" == "Z" ]]
then
  thismachine=`hostname -s`
  archname=`uname -m` 

  if [[ "Z$thismachine" == "Ziks-db1" ]]
  then
    PGLOC=/pub/A1000/cplattne/postgresql/8.1.2-iks
  elif [[ "Z$archname" == "Zx86_64" ]]
  then
    PGLOC=/pub/A1000/cplattne/postgresql/8.1.2-AMD64
  else
    PGLOC=/pub/A1000/cplattne/postgresql/8.1.2
  fi
  if [ ! -d $PGLOC ]
  then
    PGLOC=
  fi
fi

# ===================================================================
# JAVA SETTINGS
# ===================================================================

if [[ "Z$JAVA_HOME" == "Z" ]]
then
	echo "Please set the JAVA_HOME variable so that it points to your Java installation."
	exit 2
fi

JAVA=$JAVA_HOME/bin/java

if [ ! -f $JAVA ]
then
	echo "Sorry, your JAVA_HOME setting seems to be strange."
	exit 2
fi

# ===================================================================
# POSTGRESQL SETTINGS
# ===================================================================

if [[ "Z$PGLOC" == "Z" ]]
then
	echo "Please set the PGLOC variable so that it points to your PostgreSQL installation."
	exit 2
fi

if [ ! -d $PGLOC ]
then
	echo "PGLOC ($PGLOC) does not point to a directory!"
	exit 2
fi

if [ ! -d $PGLOC/bin ]
then
	echo "PGLOC/bin ($PGLOC/bin) does not point to a directory!"
	exit 2
fi

PGBIN=$PGLOC/bin

if [ ! -f $PGBIN/postmaster ]
then
	echo "Sorry, your PGLOC setting seems to be strange, $PGBIN/postmaster does not exist."
	exit 2
fi

# ===================================================================
# STOP RUNNING GANYMED ADAPTER (IF ANY)
# ===================================================================

# Check if $pid (could be plural) are running
checkpid() {
   local i

   for i in $* ; do
      [ -d "/proc/$i" ] && return 0
   done
   return 1
}

if [ -f $TOPDIR/ganymed/adapter.pid ]
then
	read pid < $TOPDIR/ganymed/adapter.pid

	echo "Stopping old Ganymed adapter (pid $pid)..."

	if checkpid $pid 2>&1
	then
		kill -TERM $pid >/dev/null 2>&1
		echo "Killed $pid with TERM"
		usleep 100000
		if checkpid $pid && sleep 1 && checkpid $pid && sleep 3 && checkpid $pid
		then
			kill -KILL $pid >/dev/null 2>&1
			echo "Killed $pid with KILL"
			usleep 100000
			checkpid $pid && sleep 1
		fi
	fi
	rm -f $TOPDIR/ganymed/adapter.pid
fi

# ===================================================================
# GENERATE LOCAL GANYMED INSTALLATION
# ===================================================================

mkdir -p $TOPDIR/ganymed
mkdir -p $TOPDIR/cluster
cp -f $ganymedfiles/* $TOPDIR/ganymed

LOG=$TOPDIR/ganymed/$thismachine.log
echo `date` > $LOG

# ===================================================================
# GENERATE CONFIG FILE
# ===================================================================

(
cat <<EOF
################################################################
# Auto Config for Ganymed Adapter
################################################################

# Global log level for Adapters

logLevel = $LOGLEVEL

# LOG4J Settings

log4jHost = $LOG4JHOST
log4jPort = $LOG4JPORT

# PostgreSQL settings

postgresqlSuperUser = $MASTER_USER
postgresqlSuperPass = $MASTER_PASSWORD
gnylib = ganymed_func.so
pgCtlBinary = $PGBIN/pg_ctl
clusterBaseDirectory = $TOPDIR/cluster
postgreSQLBasePort = $POSTGRESQL_INTERNAL_BASE_PORT

externalPort = $ADAPTER_PORT
traceBaseFilename = $TOPDIR/ganymed/trace.
maxOpenConnections = 2000
maxOpenConnectionsPerHost = 2000
maxOpenConnectionsPerCluster = 2000

enableStatisticsCollection=$STATISTICS
setXACTRerouteLimit=$XACT_REROUTE_LIMIT

EOF
) > $TOPDIR/ganymed/adapter.properties

# ===================================================================
# START ADAPTER
# ===================================================================

cd $TOPDIR/ganymed
$TOPDIR/ganymed/forker -l $LOG \
	-p $TOPDIR/ganymed/adapter.pid \
	$JAVA -Xmx1024M -Xnoclassgc -server \
	-cp $JARS ch.ethz.pc.Start

echo "Adapter started"

# ===================================================================
# DONE - ADAPTER SHOULD BE RUNNING NOW
# ===================================================================

