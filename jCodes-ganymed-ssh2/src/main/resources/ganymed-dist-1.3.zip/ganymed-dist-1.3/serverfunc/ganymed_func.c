
#include "executor/spi.h"       /* this is what you need to work with SPI */
#include "commands/trigger.h"   /* -"- and triggers */
#include "utils/tqual.h"		/* -"- and SnapshotData */
#include <ctype.h>				/* tolower () */
#include "mb/pg_wchar.h"	/* pg_mblen and so on */
#include "utils/typcache.h"
#include "storage/proc.h" /* MyProc etc */

extern Datum _ganymed_log_func(PG_FUNCTION_ARGS);

PG_FUNCTION_INFO_V1(_ganymed_log_func);
//PG_FUNCTION_INFO_V1(_ganymed_set_priority);
//PG_FUNCTION_INFO_V1(_ganymed_get_priority);
PG_FUNCTION_INFO_V1(_ganymed_get_xid);
PG_FUNCTION_INFO_V1(_ganymed_log_special);
PG_FUNCTION_INFO_V1(_ganymed_set_logging);
PG_FUNCTION_INFO_V1(_ganymed_get_log);
PG_FUNCTION_INFO_V1(_ganymed_xid2int);

//static TransactionId	act_xid = InvalidTransactionId;

/*
current_server_encoding = GetDatabaseEncoding(); 
      (current_server_encoding == PG_SQL_ASCII ||
*/

static void *insert_plan = NULL;
static int32 xid = InvalidTransactionId;
static int32 seq;

static int32 loggingEnabled = 0;

static char *currentLog = (char*) NULL;
static int32 currentLogXID = InvalidTransactionId;

static char* quote_ascii_literal(char *str)
{
   char     *result;
   char     *cp1;
   char     *cp2;
   int         len;

   len = strlen(str);
   result = palloc(len * 2 + 3);
   cp1 = str;
   cp2 = result;

   *cp2++ = '\'';
   while (len > 0)
   {
      if (*cp1 == '\'')
         *cp2++ = '\'';
      if (*cp1 == '\\')
         *cp2++ = '\\';
      *cp2++ = *cp1++;
      
      len--;
   }
   
   *cp2++ = '\'';
   *cp2++ = '\0';
   
   return result;
}

char* quoted_(char* in)
{
	static char buffer[1024];
	char *pos = buffer;

	while (*in != '\0')
	{
		char c = *in;

		if (c == '\\')
		{
			*pos++ = '\\'; 
			*pos++ = '\\';
		}else if (c == '\n')
		{
			*pos++ = '\\'; 
			*pos++ = 'n';
		}else if (c == '\r')
		{
			*pos++ = '\\'; 
			*pos++ = 'r';
		}else if (c == '\'')
		{
			*pos++ = '\\'; 
			*pos++ = '\'';
		}else if (c == '\t')
		{
			*pos++ = '\\'; 
			*pos++ = 't';
		}else
			*pos++ = c;
		in++;

		if ((pos - buffer) > 1000)
			elog(ERROR, "BUFFER > 1000");

	}
	*pos = '\0';

	return buffer;
}

void add_text_buffer(text** buff, char **pos, char* what)
{
	int len_what = strlen(what);

	int need = ((*pos) - (char*)(*buff)) + VARHDRSZ + 4 + len_what;

	if ((VARSIZE(*buff)) < need)
	{
		int da = (*pos) - (char *)(*buff);
		while ((VARSIZE(*buff)) < need)
			VARATT_SIZEP(*buff) = (VARSIZE(*buff)) + len_what + 12;
		*buff = realloc(*buff, VARSIZE(*buff));
		*pos = (char*)(*buff) + da;
	}

	memcpy(*pos, what, len_what);
	*pos += len_what;
}

Datum _ganymed_log_func(PG_FUNCTION_ARGS)
{
	Trigger    *trigger;		/* to get trigger name */
	TriggerData *trigdata = (TriggerData *) fcinfo->context;
	int			nargs;			/* # of args specified in CREATE TRIGGER */
	char	  **args;			/* argument: argnum */
	Relation	rel;			/* triggered relation */
	HeapTuple	tuple;			/* tuple to return */
	HeapTuple	newtuple = NULL;/* tuple to return */
	TupleDesc	tupdesc;		/* tuple description */
	int	i;
	int ret;
	char action;
	char *pos;
	int32 cur_xid;
	text *buf = palloc(8192);
	text *pbuf = palloc(8192);
	text *relname_buf = palloc(64);

	VARATT_SIZEP(buf) = 8192;
	VARATT_SIZEP(pbuf) = 8192;

	if (loggingEnabled == 0)
		return (Datum) 0;

	cur_xid = GetCurrentTransactionId();

	if (cur_xid != xid)
	{
		xid = cur_xid;
		seq = 0;
	}else{
		seq++;
	}

	/* Make sure trigdata is pointing at what I expect */
	if (!CALLED_AS_TRIGGER(fcinfo))
		elog(ERROR, "ganymed log trigger not fired by trigger manager");

	/* Should be called for ROW trigger */

	if (TRIGGER_FIRED_FOR_ROW(trigdata->tg_event) == FALSE)
		elog(ERROR, "ganymed log trigger must be called for each row, not on statement level");

	if (TRIGGER_FIRED_AFTER(trigdata->tg_event) == FALSE)
		elog(ERROR, "ganymed log trigger must be called AFTER");

	tuple = trigdata->tg_trigtuple;
	newtuple = trigdata->tg_newtuple;

	/* Connect to the SPI */

   if ((ret = SPI_connect()) < 0)
      elog(ERROR, "ganymed log trigger cannot connect to SPI (%d)", ret);

	if ((loggingEnabled == 1) && (insert_plan == NULL))
	{
		char query[512];
		Oid query_para_types[6];

		sprintf(query, "INSERT INTO _ganymed_log "
			"(xid, seq, gseq, relname, action, rowpred, logentry) "
			"VALUES ($1,$2,nextval('_ganymed_log_seq'),$3,$4,$5,$6);");

			query_para_types[0] = INT4OID;
			query_para_types[1] = INT4OID;
			query_para_types[2] = TEXTOID;
			query_para_types[3] = CHAROID;
			query_para_types[4] = TEXTOID;
			query_para_types[5] = TEXTOID;

		insert_plan = SPI_saveplan(SPI_prepare(query, 6, query_para_types));

		if (insert_plan == NULL)
			elog(ERROR, "ganymed log trigger unable to create insert plan (%i)", SPI_result);
	}

	trigger = trigdata->tg_trigger;
	nargs = trigger->tgnargs;
	args = trigger->tgargs;

	if (nargs < 1)
		elog(ERROR, "ganymed log trigger not enough arguments (%i)", nargs);

	rel = trigdata->tg_relation;
	tupdesc = rel->rd_att;

	if (TRIGGER_FIRED_BY_DELETE(trigdata->tg_event))
		action = 'D';
	else if (TRIGGER_FIRED_BY_UPDATE(trigdata->tg_event))
		action = 'U';
	else if (TRIGGER_FIRED_BY_INSERT(trigdata->tg_event))
		action = 'I';
	else
		elog(ERROR, "ganymed log trigger unable to get reason for invocation");

	/* So, erst mal alle keys holen */

	pos = VARDATA(pbuf); 

	if (action != 'I')
	{
		for (i=0; i < nargs; i++)
		{
			char *value;

			int pkey_fn = SPI_fnumber(tupdesc, args[i]);

			if (pkey_fn < 1)
				elog(ERROR, "ws_log: illegal pkey name.");

			if (i)
				add_text_buffer(&pbuf, &pos, " AND ");

			add_text_buffer(&pbuf, &pos, args[i]);
			add_text_buffer(&pbuf, &pos, "=");

			value = SPI_getvalue(tuple, tupdesc, pkey_fn);

			add_text_buffer(&pbuf, &pos, value ? quote_ascii_literal(value) : "NULL");
		}
	}
	*pos = '\0';

	pos = VARDATA(buf); 

	if (action == 'U')
	{
		Datum    old_value;
      Datum    new_value;
      bool     old_isnull;
      bool     new_isnull;
		int		put_comma = false;
		
		for (i=0; i < tupdesc->natts; i++)
		{
			char *val;

	//		if (tupdesc->attrs[i]->attisdropped)  FIXFIXFIX!!!
    //        continue;

			old_value = SPI_getbinval(tuple, tupdesc, i + 1, &old_isnull);
			new_value = SPI_getbinval(newtuple, tupdesc, i + 1, &new_isnull);

			if (old_isnull && new_isnull)
				continue;

			if (!old_isnull && !new_isnull)
         {
				TypeCacheEntry *type_cache;

				type_cache = lookup_type_cache(
					SPI_gettypeid(tupdesc, i + 1),
					TYPECACHE_EQ_OPR | TYPECACHE_EQ_OPR_FINFO);

				if (DatumGetBool(FunctionCall2(&(type_cache->eq_opr_finfo), old_value, new_value)))
					continue;
			}

			if (put_comma == true)
				*pos++ = ',';
			else
				put_comma = true;

			add_text_buffer(&buf, &pos, SPI_fname(tupdesc, i + 1));
			*pos++ = '=';
			val = SPI_getvalue(newtuple, tupdesc, i + 1);
			add_text_buffer(&buf, &pos, val ? quote_ascii_literal(val) : "NULL");
		}
	}

	if (action == 'I')
	{
		*pos++ = '(';
		for (i=0; i < tupdesc->natts; i++)
		{
			if (i) *pos++ = ',';
			add_text_buffer(&buf, &pos, SPI_fname(tupdesc, i + 1));
		}
		*pos++ = ')';
		*pos++ = 'V';
		*pos++ = 'A';
		*pos++ = 'L';
		*pos++ = 'U';
		*pos++ = 'E';
		*pos++ = 'S';
		*pos++ = '(';
		for (i=0; i < tupdesc->natts; i++)
		{
			char *val;
			if (i) *pos++ = ',';
			val = SPI_getvalue(tuple, tupdesc, i + 1);
			add_text_buffer(&buf, &pos, val ? quote_ascii_literal(val) : "NULL");
		}
		*pos++ = ')';
	}
	*pos = '\0';

/*
	if ((action == 'I') || (action == 'D'))
	{
		for (i=0; i < tupdesc->natts; i++)
		{
			char *val;
			add_text_buffer(&buf, &pos, "N");
			add_text_buffer(&buf, &pos, quote_ascii_literal(SPI_fname(tupdesc, i + 1)));
			add_text_buffer(&buf, &pos, quote_ascii_literal(SPI_fname(tupdesc, i + 1)));
			val = SPI_getvalue(tuple, tupdesc, i + 1);
			add_text_buffer(&buf, &pos, val ? quote_ascii_literal(val) : "NULL");
		}
	}
	*pos = '\0';
*/

	strcpy(VARDATA(relname_buf), SPI_getrelname(rel));

	VARATT_SIZEP(pbuf) = VARHDRSZ + strlen(VARDATA(pbuf)) + 1;
	VARATT_SIZEP(buf) = VARHDRSZ + strlen(VARDATA(buf)) + 1;
	VARATT_SIZEP(relname_buf) = VARHDRSZ + strlen(VARDATA(relname_buf)) + 1;

	if (loggingEnabled == 1)
	{
		Datum  args[6];
		args[0] = TransactionIdGetDatum(xid);
		args[1] = Int32GetDatum(seq);
		args[2] = PointerGetDatum(relname_buf);
		args[3] = CharGetDatum(action);
		args[4] = PointerGetDatum(pbuf);
		args[5] = PointerGetDatum(buf);

		SPI_execp(insert_plan, args, NULL, 0);
	}

	if (loggingEnabled == 2)
	{
		char tmpbuf[8000];

		if (currentLogXID == InvalidTransactionId)
		{
			currentLogXID = cur_xid;
		}else{
			if (currentLogXID != cur_xid)
				elog(ERROR, "There are unsaved replication entries. Giving up!");
		}

		sprintf(tmpbuf, "#1%s#2%c#3%s#4%s#5", VARDATA(relname_buf), action, VARDATA(pbuf), VARDATA(buf));

		if	(currentLog == (char*) NULL)
		{
			currentLog = strdup(tmpbuf);
		}else{
			char *x = (char*) malloc(sizeof(char) * (strlen(tmpbuf) + strlen(currentLog) + 1));
			strcpy(x, currentLog);
			strcat(x, tmpbuf);
			free(currentLog);
			currentLog = x;
		}
	}

	//elog(INFO, VARDATA(buf));

	SPI_finish();

	return (Datum) 0;
}

// include "postgres.h"

// include "fmgr.h"	
// include "access/xact.h"
// include "access/transam.h"

/*
Datum		_ganymed_get_priority(PG_FUNCTION_ARGS);
Datum		_ganymed_set_priority(PG_FUNCTION_ARGS);

Datum _ganymed_get_priority(PG_FUNCTION_ARGS)
{
	unsigned int prio = MyProc->ganymed_priority;
	PG_RETURN_UINT32(prio);
}

Datum _ganymed_set_priority(PG_FUNCTION_ARGS)
{
	MyProc->ganymed_priority = PG_GETARG_UINT32(0);

	return (Datum) 0;
}
*/

Datum _ganymed_set_logging(PG_FUNCTION_ARGS)
{
	loggingEnabled = PG_GETARG_UINT32(0);
	return (Datum) 0;
}

Datum _ganymed_get_log(PG_FUNCTION_ARGS)
{
	text *t = (text*) NULL;
	char *ans = currentLog;

	if (ans == (char*) NULL)
		ans = "";

	t = (text *) palloc(VARHDRSZ + strlen(ans));
	VARATT_SIZEP(t) = VARHDRSZ + strlen(ans);
	memcpy((void *) VARDATA(t), ans, strlen(ans));

	if (currentLog != (char*) NULL)
		free(currentLog);

	currentLog = (char*) NULL;
	currentLogXID = InvalidTransactionId;

   PG_RETURN_TEXT_P(t);
}

Datum _ganymed_get_xid(PG_FUNCTION_ARGS)
{  
   TransactionId my_xid = GetCurrentTransactionId();
      
   PG_RETURN_UINT32(my_xid);
}

Datum _ganymed_xid2int(PG_FUNCTION_ARGS)
{  
   PG_RETURN_UINT32(PG_GETARG_UINT32(0));
}

Datum _ganymed_log_special(PG_FUNCTION_ARGS)
{
	int32 cur_xid;
	text *statement;
	int ret;

	if (loggingEnabled == 0)
		return (Datum) 0;

	if (PG_ARGISNULL(0))
      elog(ERROR, "ganymed special log cannot accept NULL parameter");

	statement = PG_GETARG_TEXT_P(0);

	cur_xid = GetCurrentTransactionId();

	if (cur_xid != xid)
	{
		xid = cur_xid;
		seq = 0;
	}else{
		seq++;
	}

   if ((ret = SPI_connect()) < 0)
      elog(ERROR, "ganymed special log cannot connect to SPI (%d)", ret);

	if (insert_plan == NULL)
	{
		char query[512];
		Oid query_para_types[6];

		sprintf(query, "INSERT INTO _ganymed_log "
			"(xid, seq, gseq, relname, action, rowpred, logentry) "
			"VALUES ($1,$2,nextval('_ganymed_log_seq'),$3,$4,$5,$6);");

			query_para_types[0] = INT4OID;
			query_para_types[1] = INT4OID;
			query_para_types[2] = TEXTOID;
			query_para_types[3] = CHAROID;
			query_para_types[4] = TEXTOID;
			query_para_types[5] = TEXTOID;

		insert_plan = SPI_saveplan(SPI_prepare(query, 6, query_para_types));

		if (insert_plan == NULL)
			elog(ERROR, "ganymed log trigger unable to create insert plan (%i)", SPI_result);
	}

	{
		Datum  args[6];
		char null_list[6];

		strncpy(null_list, "  n n ", 6);

		//if (statement == (text*) NULL)
		//	null_list[5] = 'n';
	
		args[0] = TransactionIdGetDatum(xid);
		args[1] = Int32GetDatum(seq);
		args[2] = PointerGetDatum((void*) NULL);
		args[3] = CharGetDatum('S');
		args[4] = PointerGetDatum((void*) NULL);
		args[5] = PointerGetDatum(statement);

		SPI_execp(insert_plan, args, null_list, 0);
	}

	SPI_finish();

	return (Datum) 0;
}

