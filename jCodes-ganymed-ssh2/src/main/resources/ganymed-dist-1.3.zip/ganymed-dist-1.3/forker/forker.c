
/* ------------------------------------------------------*/
/* forker.c - COPYRIGHT (C) 2004-2005 Christian Plattner */
/* plattner@inf.ethz.ch. Last change: 23.12.2005         */
/* ------------------------------------------------------*/

#include <sys/stat.h>
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

void closeall(int fd)
{
    int fdlimit = sysconf(_SC_OPEN_MAX);

    while (fd < fdlimit)
      close(fd++);
}

void usagebye()
{
		printf ("forker. Usage: forker [ -l LOGFILE ] [ -p PIDFILE ] COMMAND [ARGS]\n");
		exit(2);
}

int main(int argc, char **argv)
{
	char *log_file = (char*) NULL;
	char *pid_file = (char*) NULL;
	int command_idx = 1;

	if (argc < 2)
		usagebye();

	if (strcmp(argv[command_idx], "-l") == 0)
	{
		if (argc <= (command_idx+2))
			usagebye();

		log_file = argv[command_idx+1];
		command_idx += 2;
	}

	if (strcmp(argv[command_idx], "-p") == 0)
	{
		if (argc <= (command_idx+2))
			usagebye();

		pid_file = argv[command_idx+1];
		command_idx += 2;
	}

	if (argc <= command_idx)
		usagebye();

	switch (fork())
	{
		case 0:  break;
		case -1: return -1;
		default: _exit(0);
	}

	if (setsid() < 0)
		return -1;

	switch (fork())
	{
		case 0:  break;
		case -1: return -1;
		default: _exit(0);
	}

	closeall(0);

	open("/dev/null", O_RDWR);

	if (log_file != (char*) NULL)
	{
		int fd_logfile = open(log_file, O_WRONLY | O_CREAT | O_APPEND, S_IRUSR | S_IWUSR);
		if (fd_logfile != 1)
		{
			dup(0); dup(0);
		}else{
			dup(1);
		}
	}else{
		dup(0); dup(0);
	}

	if (pid_file != (char*) NULL)
	{
		FILE* pidfile = fopen(pid_file, "w");
		if (pidfile != (FILE*) NULL)
		{
			fprintf(pidfile, "%i", getpid());
			fflush(pidfile);
			fclose(pidfile);
		}else{
			fprintf(stderr, "cannot write pid file %s\n", pid_file);
		}
	}

	execvp(argv[command_idx], &argv[command_idx]);

	fprintf(stderr, "cannot execute %s\n", argv[command_idx]);

	if (pid_file != (char*) NULL)
		unlink(pid_file);

	exit(2);
}

